MineArea — Minecraft Java 1.21.11 / Fabric

Three area-mining pickaxes: 3x3, 5x5, 7x7. Bedrock is excluded by the mod logic.

Build locally with Java 21 and Gradle 9.2.0:
  gradle build

The GitHub Actions workflow in .github/workflows/build.yml builds the mod and uploads a MineArea-JAR artifact on each push to main or manual workflow dispatch.

Note: this project archive contains source code and a CI workflow, not a precompiled JAR.
