package ru.imka.minearea;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ToolMaterials;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import java.util.Map;
import java.util.UUID;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class MineAreaMod implements ModInitializer {
    public static final String MOD_ID = "minearea";
    private static final Map<UUID, Direction> LAST_FACE = new ConcurrentHashMap<>();
    // Prevent recursive area-mining when breakBlock fires AFTER events for each extra block.
    private static final Set<UUID> MINING_AREA = ConcurrentHashMap.newKeySet();

    public static final Item PICKAXE_3X3 = register("pickaxe_3x3");
    public static final Item PICKAXE_5X5 = register("pickaxe_5x5");
    public static final Item PICKAXE_7X7 = register("pickaxe_7x7");

    private static Item register(String name) {
        // Netherite mining level and durability; each item gets its own model and texture.
        Item item = new Item(new Item.Settings().pickaxe(ToolMaterials.NETHERITE, 1.0F, -2.8F));
        return Registry.register(Registries.ITEM, Identifier.of(MOD_ID, name), item);
    }

    @Override
    public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> {
            entries.add(PICKAXE_3X3);
            entries.add(PICKAXE_5X5);
            entries.add(PICKAXE_7X7);
        });

        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
            if (!world.isClient()) LAST_FACE.put(player.getUuid(), direction);
            return ActionResult.PASS;
        });

        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (!(world instanceof ServerWorld serverWorld)) return;
            UUID playerId = player.getUuid();
            if (MINING_AREA.contains(playerId)) return;
            ItemStack tool = player.getMainHandStack();
            int size = getAreaSize(tool);
            if (size == 0 || state.isOf(Blocks.BEDROCK)) return;

            MINING_AREA.add(playerId);
            try {
                Direction face = LAST_FACE.getOrDefault(playerId, player.getHorizontalFacing().getOpposite());
                int radius = size / 2;
                for (int a = -radius; a <= radius; a++) {
                    for (int b = -radius; b <= radius; b++) {
                        if (a == 0 && b == 0) continue;
                        BlockPos target = getOffset(pos, face, a, b);
                        if (target.getY() < serverWorld.getBottomY() || target.getY() >= serverWorld.getTopY()) continue;
                        BlockState targetState = serverWorld.getBlockState(target);
                        if (targetState.isAir() || targetState.isOf(Blocks.BEDROCK)) continue;
                        if (targetState.getHardness(serverWorld, target) < 0) continue;
                        // Do not mine blocks the player/tool cannot harvest.
                        if (!player.canHarvest(targetState)) continue;
                        if (serverWorld.breakBlock(target, true, player)) {
                            if (tool.isDamageable()) tool.damage(1, player, net.minecraft.entity.EquipmentSlot.MAINHAND);
                            if (tool.isEmpty()) return;
                        }
                    }
                }
            } finally {
                MINING_AREA.remove(playerId);
            }
        });
    }

    private static int getAreaSize(ItemStack stack) {
        if (stack.isOf(PICKAXE_3X3)) return 3;
        if (stack.isOf(PICKAXE_5X5)) return 5;
        if (stack.isOf(PICKAXE_7X7)) return 7;
        return 0;
    }

    private static BlockPos getOffset(BlockPos center, Direction face, int a, int b) {
        return switch (face.getAxis()) {
            case Y -> center.add(a, 0, b);       // Looking at top/bottom: horizontal plane
            case X -> center.add(0, a, b);       // Looking at east/west: Y-Z plane
            case Z -> center.add(a, b, 0);       // Looking at north/south: X-Y plane
        };
    }
}
