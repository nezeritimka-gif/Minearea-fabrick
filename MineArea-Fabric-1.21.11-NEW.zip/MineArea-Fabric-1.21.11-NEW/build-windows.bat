@echo off
setlocal
cd /d "%~dp0"
echo MineArea Pickaxes - Minecraft Java 1.21.11 Fabric
where java >nul 2>nul || (echo ERROR: Install JDK 21 first. & pause & exit /b 1)
java -version 2>&1 | findstr /C:"21." >nul || echo WARNING: Java 21 is recommended for Minecraft 1.21.11.
if exist gradlew.bat (
  call gradlew.bat build
) else (
  where gradle >nul 2>nul || (echo ERROR: Gradle is not installed. Open this folder in IntelliJ IDEA and run Gradle task build. & pause & exit /b 1)
  call gradle build
)
if errorlevel 1 (
  echo BUILD FAILED. Check internet connection and Gradle error output.
  pause
  exit /b 1
)
echo.
echo Build complete. Look for the mod JAR in build\libs\
explorer "%~dp0build\libs"
pause
